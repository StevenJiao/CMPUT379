#include "shell379.hpp"

int main(int argc, char const *argv[])
{
    // initialize and run shell
    Shell379 shell;
    shell.run();
    return 0;
}
